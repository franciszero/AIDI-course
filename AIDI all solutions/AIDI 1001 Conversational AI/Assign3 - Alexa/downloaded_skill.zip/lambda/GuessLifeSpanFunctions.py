import json
import random
import datetime
import pytz

species_lst0 = []
with open("./doc/living_the_longest.json") as f:
    species_lst0 = json.load(f)

def get_remaining_species_lst(used_species = []):
    remaining_species_lst = [species for species in species_lst0 if species not in used_species]
    return random.shuffle(remaining_species_lst)[0]